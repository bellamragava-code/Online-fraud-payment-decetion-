# Fraud Payment Detection  
Simple ML project for detecting fraudulent transactions.

## Files
- `model.py` — ML code  
- `fraud.csv` — sample dataset  
- `README.md` — project info
